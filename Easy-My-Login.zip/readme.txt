﻿=== Easy My Login ===
Contributors: wp-qaleb.ir
Donate link: http://wp-qaleb.ir
Tags:  easy my login, plugin, loginform, user_login, user_pass,register
Requires at least: 3.0.1
Tested up to: 5.4.1
Stable tag: 1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Here is a short description of the plugin. This should be no more than 150 characters. No markup here.
== Description ==
With this plugin, the default WordPress login page will change its appearance. Just install and activate the plugin. Your WordPress login page will change automatically.
A few notes about the sections above:
== Installation ==
This section describes how to install the plugin and get it working.
e.g.
1.Install the plugin either via the WordPress.org plugin directory, or by uploading the files to your server (in the /wp-content/plugins/ directory).
2.Activate the User Registration plugin through the ‘Plugins’ menu in WordPress.
== Frequently Asked Questions ==
= Do I need to have coding skills to use the User Registration Plugin? =
No, you don’t need any coding skills.
= What about foo bar? =
Answer to foo bar dilemma.
== Screenshots ==
1. Log In
2. Lost Password
3. Registration Form
== Changelog ==
= 1.0 =
* A change since the previous version.
* Another change.
= 0.5 =
* List versions from most recent at top to oldest at bottom.
== Upgrade Notice ==
= 1.0 =
Upgrade notices describe the reason a user should upgrade. No more than 300 characters.
= 0.5 =
This version fixes a security related bug. Upgrade immediately.